import React, { useState } from "react";

export const SuperAdminLogin = (props) => {
    const [pass, setPass] = useState('');
    const [name, setName] = useState('');
    const [nameError, setNameError] = useState('');
    const [passwordError, setPasswordError] = useState('');
    const handleClick = (event) => {
        event.preventDefault();

        let valid = true;
        if (name.trim() === '') {
            valid = false;
            setNameError('Name is required');
          }else {
            setNameError('');
          }
        if (pass.trim()==''){
            valid= false;
            setPasswordError('password is required');
        }else if (!/(?=.*[a-zA-Z])(?=.*\d)(?=.*[@#$%^&*!])[A-Za-z\d@#$%^&*!]+/.test(pass) || pass.length<10) {
            valid = false;
            setPasswordError('Password must contain a-z,0-9 special characters at least 10 characters');
        }else {
          setPasswordError('');
        }
    
        if (valid) {
          alert('Successfully registered!');
        }
      };

    return (
        <div className="auth-form-container">
            <h2>SuperAdmin Login Page</h2>
            <form className="signup-form">
                <label htmlFor="name">Full name</label><br></br>
                <input value={name} name="name" onChange={(e) => setName(e.target.value)} id="name" placeholder="full Name" /><br></br>
                <p style={{ color: 'black' }}>{nameError}</p>
                <label htmlFor="password">Password</label><br />
                <input value={pass} onChange={(e) => setPass(e.target.value)} type="password" placeholder="********" id="password" name="password" /><br />
                <p style={{ color: 'black' }}>{passwordError}</p>
                <button type="submit" onClick={handleClick}>Login</button>
            </form><br />
            <button className="submit" onClick={() => props.onForm('superadminSignup')}>Super Admin Signup</button><br />


        </div>
    );
}
