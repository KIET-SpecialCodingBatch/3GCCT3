const express = require('express')
const cors = require('cors')
const app = express()

app.use(express.json())
app.use(cors())
const PORT = 8080
app.listen(PORT, () => {
    console.log(`Server is running on PORT ${PORT}...`)
})
const mongoose = require('mongoose')
const loginSignupDB = 'mongodb://0.0.0.0:27017/login_singup_pages'
mongoose.connect(loginSignupDB, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => {
    console.log('Database connected..');
});
const login_singup_pages = require('./Model/login_singup_pages')
app.post('/add-data', async(req,res) => {
    const mentor_num = new login_singup_pages(req.body)
    try{
        await mentor_num.save()
        res.status(201).json({
            status: 'Success',
            data : {
                mentor_num
            }
        })
    }catch(err){
        res.status(500).json({
            status: 'Failed',
            message : err
        })
    }
})
app.get('/get-data', async (req,res) => {
    const mentorNumbers = await login_singup_pages.find({})
    try{
        res.status(200).json({
            status : 'Success',
            data : {
                mentorNumbers
            }
        })
    }catch(err){
        res.status(500).json({
            status: 'Failed',
            message : err
        })
    }
})
app.patch('/update-data/:id', async (req,res) => {
    const updateddata = await login_singup_pages.findByIdAndUpdate(req.params.id,req.body,{
        new : true,
        runValidators : true
      })
    try{
        res.status(200).json({
            status : 'Success',
            data : {
              updateddata
            }
          })
    }catch(err){
        console.log(err)
    }
})
app.delete('/delete-data/:id', async(req,res) => {
    await login_singup_pages.findByIdAndDelete(req.params.id)
    
    try{
      res.status(204).json({
          status : 'Success',
          data : {}
      })
    }catch(err){
        res.status(500).json({
            status: 'Failed',
            message : err
        })
    }
})




const admins = require('./Model/admins')

app.post('/add-admin', async(req,res) => {
    const admin = new admins(req.body)
    try{
        await admin.save()
        res.status(201).json({
            status: 'Success',
            data : {
                admin
            }
        })
    }catch(err){
        res.status(500).json({
            status: 'Failed',
            message : err
        })
    }
})


app.get('/get-admin', async (req,res) => {
    const admin = await admins.find({})
    try{
        res.status(200).json({
            status : 'Success',
            data : {
                admin
            }
        })
    }catch(err){
        res.status(500).json({
            status: 'Failed',
            message : err
        })
    }
})

app.patch('/update-admin/:id', async (req,res) => {
    const updateadmin = await admins.findByIdAndUpdate(req.params.id,req.body,{
        new : true,
        runValidators : true
      })
    try{
        res.status(200).json({
            status : 'Success',
            data : {
                updateadmin
            }
          })
    }catch(err){
        console.log(err)
    }
})

app.delete('/delete-admin/:id', async(req,res) => {
    await admins.findByIdAndDelete(req.params.id)
    
    try{
      res.status(204).json({
          status : 'Success',
          data : {}
      })
    }catch(err){
        res.status(500).json({
            status: 'Failed',
            message : err
        })
    }
})

const superadmins = require('./Model/superadmins')
app.post('/add-superadmin', async(req,res) => {
    const superadmin = new superadmins(req.body)
    try{
        await superadmin.save()
        res.status(201).json({
            status: 'Success',
            data : {
                superadmin
            }
        })
    }catch(err){
        res.status(500).json({
            status: 'Failed',
            message : err
        })
    }
})


app.get('/get-superadmin', async (req,res) => {
    const superadmin = await superadmins.find({})
    try{
        res.status(200).json({
            status : 'Success',
            data : {
                superadmin
            }
        })
    }catch(err){
        res.status(500).json({
            status: 'Failed',
            message : err
        })
    }
})

app.patch('/update-superadmin/:id', async (req,res) => {
    const updatesuperadmin = await superadmins.findByIdAndUpdate(req.params.id,req.body,{
        new : true,
        runValidators : true
      })
    try{
        res.status(200).json({
            status : 'Success',
            data : {
                updatesuperadmin
            }
          })
    }catch(err){
        console.log(err)
    }
})

app.delete('/delete-superadmin/:id', async(req,res) => {
    await superadmins.findByIdAndDelete(req.params.id)
    
    try{
      res.status(204).json({
          status : 'Success',
          data : {}
      })
    }catch(err){
        res.status(500).json({
            status: 'Failed',
            message : err
        })
    }
})