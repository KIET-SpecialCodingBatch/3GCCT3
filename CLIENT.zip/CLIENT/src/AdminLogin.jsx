import React, { useState } from "react";

export const AdminLogin = (props) => {
    const [email, setEmail] = useState('');
    const [pass, setPass] = useState('');
    const [emailError, setEmailError] = useState('');
    const [passwordError, setPasswordError] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Admin Signup:', email);
        // Add your admin signup logic here
    }
     const handleClick = (event) => {
        event.preventDefault();

        let valid = true;
        if (email.trim() === '') {
          valid = false;
          setEmailError('Email is required');
        }else if (!email.includes('@')) {
            valid = false;
            setEmailError('Email must contain "@" symbol');
        }else {
          setEmailError('');
        }
        if (pass.trim()==''){
            valid= false;
            setPasswordError('password is required');
        }else if (!/(?=.*[a-zA-Z])(?=.*\d)(?=.*[@#$%^&*!])[A-Za-z\d@#$%^&*!]+/.test(pass) || pass.length<12) {
            valid = false;
            setPasswordError('Password must contain a-z,0-9 special characters at least 12 characters');
        } else {
          setPasswordError('');
        }
    
        if (valid) {
          alert('Successfully logined!');
        }
      };

    return (
        <div className="auth-form-container">
            <h2>Admin Login Page</h2>
            <form className="signup-form" onSubmit={handleSubmit}>
                <label htmlFor="email">Email</label><br></br>
                <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="Email" id="email" name="email" /><br></br>
                 <p style={{ color: 'black' }}>{emailError}</p>
                <label htmlFor="password">Password</label><br></br>
                <input value={pass} onChange={(e) => setPass(e.target.value)} type="password" placeholder="********" id="password" name="password" /><br></br>
                <p style={{ color: 'black' }}>{passwordError}</p>
                <button type="submit" onClick={handleClick}>Login</button>
            </form><br></br>
            <button className="submit" onClick={() => props.onSwitch('adminSignup')}>Admin signup</button><br></br>
            
        </div>
    );
}

