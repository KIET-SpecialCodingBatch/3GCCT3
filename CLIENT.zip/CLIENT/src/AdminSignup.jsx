import React, { useState } from "react";

export const AdminSignup = (props) => {
    const [email, setEmail] = useState('');
    const [pass, setPass] = useState('');
    const [name, setName] = useState('');
    const [nameError, setNameError] = useState('');
    const [emailError, setEmailError] = useState('');
    const [passwordError, setPasswordError] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(email);
    }
    const handleClick = (event) => {
        event.preventDefault();

        let valid = true;
        if (name.trim() === '') {
            valid = false;
            setNameError('Name is required');
          }else {
            setNameError('');
          }
        if (email.trim() === '') {
          valid = false;
          setEmailError('Email is required');
        }else if (!email.includes('@')) {
            valid = false;
            setEmailError('Email must contain "@" symbol');
        }else {
          setEmailError('');
        }
        if (pass.trim()==''){
            valid= false;
            setPasswordError('password is required');
        }else if (!/(?=.*[a-zA-Z])(?=.*\d)(?=.*[@#$%^&*!])[A-Za-z\d@#$%^&*!]+/.test(pass) || pass.length<12) {
            valid = false;
            setPasswordError('Password must contain a-z,0-9 special characters at least 12 characters');
        }else {
          setPasswordError('');
        }
    
        if (valid) {
          alert('Successfully registered!');
        }
      };

    return (
        <div className="auth-form-container">
            <h2>SuperAdmin Signup Page</h2>
            <form className="signup-form" onSubmit={handleSubmit}>
                <label htmlFor="name">Full name</label><br></br>
                <input value={name} name="name" onChange={(e) => setName(e.target.value)} id="name" placeholder="full Name" /><br></br>
                <p style={{ color: 'black' }}>{nameError}</p>
                <label htmlFor="email">Email</label><br></br>
                <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="Email" id="email" name="email" /><br></br>
                <p style={{ color: 'black' }}>{emailError}</p>
                <label htmlFor="password">Password</label><br></br>
                <input value={pass} onChange={(e) => setPass(e.target.value)} type="password" placeholder="********" id="password" name="password" /><br></br>
                <p style={{ color: 'black' }}>{passwordError}</p>
                <button type="submit" onClick={handleClick}>Sign Up</button>
            </form><br></br>            
            <button className="submit" onClick={() => props.onSwitch('adminLogin')}>Admin Login</button><br></br>
            
        </div>
    );
}
