import React, { useState } from "react";
import logo from './logo.svg';
import './App.css';
import { Login } from "./Login";
import { Register } from "./Register";
import { AdminLogin } from "./AdminLogin";
import { AdminSignup } from "./AdminSignup";
import {SuperAdminLogin} from "./Superadminlogin";
import {SuperAdminSignup} from "./Superadminsignup";

function App() {
  const [userForm, setUserForm] = useState('login');
  const [adminForm, setAdminForm] = useState('adminLogin');
  const [SuperadminForm, setSuperAdminForm] = useState('superadminLogin');


  const toggleUserForm = (formName) => {
    setUserForm(formName);
  }

  const toggleAdminForm = (formName) => {
    setAdminForm(formName);
  }
  const toggleSuperAdminForm = (formName) => {
    setSuperAdminForm(formName);
  }
  return (
    <div className="App">
      {
        userForm === "login" ? (
          <>
            <Login onFormSwitch={toggleUserForm} />
            
          </>
        ) : (
          <>
            <Register onFormSwitch={toggleUserForm} />
           
          </>
        )
      }

      {
        adminForm === "adminLogin" ? (
          <>
            <AdminLogin onSwitch={toggleAdminForm} />
          
          </>
        ) : (
          <>
            <AdminSignup onSwitch={toggleAdminForm} />
           
          </>
        )
      }
      {
        SuperadminForm === "superadminLogin" ? (
          <>
            <SuperAdminLogin onForm={toggleSuperAdminForm} />
          
          </>
        ) : (
          <>
            <SuperAdminSignup onForm={toggleSuperAdminForm} />
           
          </>
        )
      }
    </div>
  );
}

export default App;
