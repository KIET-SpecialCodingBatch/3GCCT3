const mongoose = require('mongoose')

const AdminSchema = new mongoose.Schema({
    name : {
        type : String,
        required : true
    },
    email : {
        type : String,
        required : true
    },
    pass : {
        type : String,
        required : true
    }
})

const admins  = mongoose.model('admins',AdminSchema)

module.exports = admins