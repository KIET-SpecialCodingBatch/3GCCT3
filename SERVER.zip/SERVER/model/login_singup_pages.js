const mongoose = require('mongoose')

const LoginSingupSchema = new mongoose.Schema({
    name : {
        type : String,
        required : true
    },
    email : {
        type : String,
        required : true
    },
    pass : {
        type : String,
        required : true
    }
})

const login_singup_pages  = mongoose.model('login_singup_pages',LoginSingupSchema)
module.exports = login_singup_pages